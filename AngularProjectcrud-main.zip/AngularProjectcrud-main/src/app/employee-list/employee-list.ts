import { Component, OnInit } from '@angular/core';
import { RestApiService } from "../shared/rest-api.service";
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-list',
  imports: [RouterLink, CommonModule, FormsModule],
  templateUrl: './employee-list.html',
  styleUrl: './employee-list.css',
})
export class EmployeeList implements OnInit{

  Employee: any = [];

  constructor(
    public restApi: RestApiService
  ){ }

  ngOnInit() {
    this.loadEmployees()
  }

  //Get emloyees list
  loadEmployees() {
    return this.restApi.getEmployees().subscribe((data: {}) => {
      this.Employee = data;
    })
  }

  //delete employee
  deleteEmployee(id: any) {
    if(window.confirm('Are you sure, you want to delete?')){
      this.restApi.deleteEmployee(id).subscribe(data =>{
        this.loadEmployees()
      })
    }
  }
}
