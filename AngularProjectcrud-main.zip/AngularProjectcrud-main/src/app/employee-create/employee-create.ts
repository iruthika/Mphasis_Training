import { Component, Input, OnInit, ɵɵdeferPrefetchOnViewport } from '@angular/core';
import { RestApiService } from '../shared/rest-api.service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-create',
  imports: [CommonModule,
    FormsModule,RouterLink
  ],
  templateUrl: './employee-create.html',
  styleUrl: './employee-create.css',
})
export class EmployeeCreate implements OnInit{

  @Input() employeeDetails = { name: '', email: '', phone: 0}

  constructor(
    public restApi: RestApiService,
    public router: Router
  ) { }

  ngOnInit() { }

  addEmployee() {
    this.restApi.createEmployee(this.employeeDetails).subscribe((data:{}) => {
      this.router.navigate(['/employee-list']);
    })
  }
   
}
