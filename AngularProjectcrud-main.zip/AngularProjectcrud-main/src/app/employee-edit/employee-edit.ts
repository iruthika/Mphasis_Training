import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../shared/rest-api.service';
import { ActivatedRoute, ParamMap, RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-edit',
  imports: [FormsModule, 
    CommonModule,
    RouterLink
  ],
  templateUrl: './employee-edit.html',
  styleUrl: './employee-edit.css',
})
export class EmployeeEdit implements OnInit{
  id: any;
  employeeData:any = {};


  constructor(
    public restApi: RestApiService,
    public actRoute: ActivatedRoute,
    public router:Router
  ){ 
    this.id = this.actRoute.snapshot.params['id']; 
  }

  ngOnInit() {
     this.actRoute.paramMap.subscribe((params: ParamMap) => {
        this.id =params.get('id')
      })
    this.restApi.getEmployee(this.id).subscribe((data:{}) => {
      this.employeeData = data;
      });
      
  }

  updateEmployee(){
    if(window.confirm('Are you sure, you want to update?')){
      this.restApi.updateEmployee(this.id, this.employeeData).
      subscribe((data) => {
        this.router.navigate(['/employees-list'])
      
    })
  
    }
  }
}


