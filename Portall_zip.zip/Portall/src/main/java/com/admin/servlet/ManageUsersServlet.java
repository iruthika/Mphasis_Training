package com.admin.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import com.testQuiz.dao.UserDAO;
import com.testQuiz.entity.User;
import com.testQuiz.utils.DBUtil;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/users")
public class ManageUsersServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        if (!"admin".equals(role)) {
        	response.sendRedirect(request.getContextPath() +"adminJsp/unauthorized.jsp");
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            UserDAO userDAO = new UserDAO(conn);
            List<User> users = userDAO.getAllUsers();
            request.setAttribute("users", users);
            RequestDispatcher dispatcher = request.getRequestDispatcher("adminJsp/manage_users.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error loading users", e);
        }
    }
}
