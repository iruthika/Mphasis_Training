package com.admin.servlet;

import java.io.IOException;
import java.sql.Connection;

import com.testQuiz.dao.QuizDAO;
import com.testQuiz.utils.DBUtil;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/create-quiz")
public class CreateQuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String quizName = request.getParameter("quizName");
        HttpSession session = request.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        if (!"admin".equals(role)) {
        	response.sendRedirect(request.getContextPath() +"adminJsp/unauthorized.jsp");
            return;
        }
        try (Connection conn = DBUtil.getConnection()) {
            QuizDAO quizDAO = new QuizDAO(conn);
            quizDAO.createQuiz(quizName);
            response.sendRedirect("admin");
        } catch (Exception e) {
            throw new ServletException("Error creating quiz", e);
        }
    }
}
