package com.admin.servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/admin")
public class AdminDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;
System.out.println(role);
        if (!"admin".equals(role)) {
            response.sendRedirect(request.getContextPath() +"adminJsp/unauthorized.jsp");
            return;
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("adminJsp/admin_dashboard.jsp");
        dispatcher.forward(request, response);
    }
}