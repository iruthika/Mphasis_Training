package com.admin.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.testQuiz.utils.DBUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/assign-questions")
public class AssignQuestionsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int quizId = Integer.parseInt(request.getParameter("quizId"));
        String[] questionIds = request.getParameterValues("questionIds");

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO quiz_questions (quiz_id, question_id) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                for (String qid : questionIds) {
                    stmt.setInt(1, quizId);
                    stmt.setInt(2, Integer.parseInt(qid));
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
            response.sendRedirect("admin_dashboard.jsp");
        } catch (Exception e) {
            throw new ServletException("Error assigning questions", e);
        }
    }
}
