package com.admin.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.testQuiz.utils.DBUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/add-question")
public class ManageQuestionsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String questionText = request.getParameter("questionText");
        String optionA = request.getParameter("optionA");
        String optionB = request.getParameter("optionB");
        String optionC = request.getParameter("optionC");
        String optionD = request.getParameter("optionD");
        String correctOption = request.getParameter("correctOption");

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, questionText);
                stmt.setString(2, optionA);
                stmt.setString(3, optionB);
                stmt.setString(4, optionC);
                stmt.setString(5, optionD);
                stmt.setString(6, correctOption);
                stmt.executeUpdate();
            }
            response.sendRedirect("admin/manage_questions.jsp");
        } catch (Exception e) {
            throw new ServletException("Error adding question", e);
        }
    }
}
