package com.admin.entity;

public class Score {
    private int scoreId;
    private int userId;
    private int quizId;
    private int score;

    private String username;
    private String quizName;

    public Score() {}

    public Score(int userId, int quizId, int score) {
        this.userId = userId;
        this.quizId = quizId;
        this.score = score;
    }

    public int getScoreId() {
        return scoreId;
    }

    public void setScoreId(int scoreId) {
        this.scoreId = scoreId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getQuizId() {
        return quizId;
    }

    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getQuizName() {
        return quizName;
    }

    public void setQuizName(String quizName) {
        this.quizName = quizName;
    }

    @Override
    public String toString() {
        return "Score [scoreId=" + scoreId + ", userId=" + userId + ", quizId=" + quizId +
               ", score=" + score + ", username=" + username + ", quizName=" + quizName + "]";
    }
    public Score(String username, int score) {
        this.username = username;
        this.score = score;
    }

}
