package com.testQuiz.Servlets;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.Enumeration;

import com.testQuiz.dao.UserQuizAttemptDAO;
import com.testQuiz.dao.UserDAO;
import com.testQuiz.dao.QuizDAO;
import com.testQuiz.entity.UserQuizAttempt;
import com.testQuiz.entity.User;
import com.testQuiz.entity.Quiz;
import com.testQuiz.utils.DBUtil;

@WebServlet("/SubmitQuiz")
public class SubmitQuizServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        int quizId = Integer.parseInt(request.getParameter("quizId"));
        int score = 0;

        try (Connection conn = DBUtil.getConnection()) {
            Enumeration<String> paramNames = request.getParameterNames();

            while (paramNames.hasMoreElements()) {
                String param = paramNames.nextElement();
                if (param.startsWith("question_")) {
                    int questionId = Integer.parseInt(param.split("_")[1]);
                    String selectedAnswer = request.getParameter(param);
                    String correctAnswer = request.getParameter("correct_" + questionId);
                    System.out.println(selectedAnswer);
                    System.out.println(correctAnswer);
                    if (selectedAnswer != null && correctAnswer != null &&
                        selectedAnswer.trim().equalsIgnoreCase(correctAnswer.trim())) {
                        score++;
                    }
                }
            }

            // Save attempt
            UserQuizAttemptDAO attemptDAO = new UserQuizAttemptDAO(conn);
            UserQuizAttempt attempt = new UserQuizAttempt();
            attempt.setUserId(userId);
            attempt.setQuizId(quizId);
            attempt.setScore(score);
            attemptDAO.saveAttempt(attempt);

            // Fetch username
            UserDAO userDAO = new UserDAO(conn);
            User user = userDAO.getUserById(userId);
            String username = (user != null) ? user.getUsername() : "Unknown";

            // Fetch quiz name
            QuizDAO quizDAO = new QuizDAO(conn);
            Quiz quiz = quizDAO.getQuizById(quizId);
            String quizName = (quiz != null) ? quiz.getTitle() : "Unknown Quiz";

            // Pass data to result.jsp
            request.setAttribute("username", username);
            request.setAttribute("quizName", quizName);
            request.setAttribute("score", score);

            RequestDispatcher dispatcher = request.getRequestDispatcher("/result.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error submitting quiz", e);
        }
    }
}
