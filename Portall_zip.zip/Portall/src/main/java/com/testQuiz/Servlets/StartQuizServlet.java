package com.testQuiz.Servlets;


import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import com.testQuiz.dao.QuizDAO;
import com.testQuiz.entity.Quiz;
import com.testQuiz.utils.DBUtil;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
@WebServlet("/StartQuiz")
public class StartQuizServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DBUtil.getConnection()) {
            QuizDAO quizDAO = new QuizDAO(conn);
            List<Quiz> quizzes = quizDAO.getAllQuizzes();
            request.setAttribute("quizzes", quizzes);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/quiz_list.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error loading quizzes", e);
        }
    }
}