package com.testQuiz.Servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import com.testQuiz.dao.ScoreDAO;
import com.testQuiz.entity.ScoreEntry;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.annotation.WebServlet;

@WebServlet("/LeaderboardServlet")
public class LeaderboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String quizIdParam = request.getParameter("quizId");
        if (quizIdParam == null || quizIdParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing quizId parameter");
            return;
        }

        int quizId = Integer.parseInt(quizIdParam);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz_portal", "root", "root@39")) {
            ScoreDAO scoreDAO = new ScoreDAO(conn);
            List<ScoreEntry> leaderboard = scoreDAO.getTopScoresForQuiz(quizId);

            request.setAttribute("leaderboard", leaderboard);
            request.getRequestDispatcher("leaderboard.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error while fetching leaderboard", e);
        }
    }
}