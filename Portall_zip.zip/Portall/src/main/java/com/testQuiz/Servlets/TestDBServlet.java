package com.testQuiz.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.testQuiz.utils.DBUtil;

@WebServlet("/TestDB")
public class TestDBServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try (Connection conn = DBUtil.getConnection()) {
                if (conn != null && !conn.isClosed()) {
                    out.println("<h3 style='color:green;'>✅ Database connection successful!</h3>");
                } else {
                    out.println("<h3 style='color:red;'>❌ Database connection failed: Connection is null or closed.</h3>");
                }
            } catch (SQLException e) {
                out.println("<h3 style='color:red;'>❌ Database connection failed: " + e.getMessage() + "</h3>");
                e.printStackTrace(out);
            }
        }
    }
}
