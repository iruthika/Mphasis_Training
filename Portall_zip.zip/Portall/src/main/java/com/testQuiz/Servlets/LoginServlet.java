package com.testQuiz.Servlets;


import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;

import com.testQuiz.dao.UserDAO;
import com.testQuiz.entity.User;
import com.testQuiz.utils.DBUtil;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DBUtil.getConnection()) {
            UserDAO userDAO = new UserDAO(conn);
            User user = userDAO.getUserByUsername(username);

            if (user != null && user.getPassword().equals(password) && user.getRole().equalsIgnoreCase("user")) {
                HttpSession session = request.getSession();
                session.setAttribute("userId", user.getId());
                response.sendRedirect("StartQuiz");
            }
            else if(user != null && user.getPassword().equals(password) && user.getRole().equalsIgnoreCase("admin")) {
                HttpSession session = request.getSession();
                session.setAttribute("role", "admin");
            	response.sendRedirect("admin");
            }
            else {
                request.setAttribute("error", "Invalid credentials");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            throw new ServletException("Login error", e);
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.sendRedirect("login.jsp");
}
}
