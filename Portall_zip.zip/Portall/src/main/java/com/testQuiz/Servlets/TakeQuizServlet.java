package com.testQuiz.Servlets;

import com.testQuiz.dao.QuestionDAO;
import com.testQuiz.entity.Question;
import com.testQuiz.utils.DBUtil;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/TakeQuiz")
public class TakeQuizServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String quizIdParam = request.getParameter("quizId");
        if (quizIdParam == null || quizIdParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing quizId parameter");
            return;
        }

        int quizId;
        try {
            quizId = Integer.parseInt(quizIdParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid quizId format");
            return;
        }

        // Optional: check if user is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            QuestionDAO questionDAO = new QuestionDAO(conn);
            List<Question> questions = questionDAO.getQuestionsForQuiz(quizId);

            if (questions == null || questions.isEmpty()) {
                request.setAttribute("error", "No questions found for this quiz.");
            }

            request.setAttribute("questions", questions);
            request.setAttribute("quizId", quizId);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/quiz.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error loading questions", e);
        }
    }
}
