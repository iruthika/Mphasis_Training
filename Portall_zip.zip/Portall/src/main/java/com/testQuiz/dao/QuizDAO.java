package com.testQuiz.dao;

import java.sql.*;
import java.util.*;

import com.testQuiz.entity.Quiz;

public class QuizDAO {
    private Connection connection;

    public QuizDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Quiz> getAllQuizzes() throws SQLException {
        List<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT * FROM quizzes";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Quiz quiz = new Quiz();
                quiz.setId(rs.getInt("quiz_id"));
                quiz.setTitle(rs.getString("quiz_name"));
         
                quizzes.add(quiz);
            }
        }
        return quizzes;
    }

    public Quiz getQuizById(int quizId) throws SQLException {
        String sql = "SELECT * FROM quizzes WHERE quiz_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, quizId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Quiz quiz = new Quiz();
                quiz.setId(rs.getInt("quiz_id"));
                quiz.setTitle(rs.getString("quiz_name"));
                return quiz;
            }
        }
        return null;
    }

	public void createQuiz(String quizName) throws SQLException {
    String sql = "INSERT INTO quizzes (quiz_name) VALUES (?)";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, quizName);
        stmt.executeUpdate();
    }
}

}