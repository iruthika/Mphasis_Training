package com.testQuiz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.admin.entity.Score;

public class ScoreDAO {
    private Connection connection;

    public ScoreDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Score> getTopScoresForQuiz(int quizId) throws SQLException {
        List<Score> leaderboard = new ArrayList<>();
        String sql = "SELECT u.username, s.score " +
                     "FROM scores s JOIN users u ON s.user_id = u.user_id " +
                     "WHERE s.quiz_id = ? ORDER BY s.score DESC LIMIT 10";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, quizId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String username = rs.getString("username");
                int score = rs.getInt("score");
                leaderboard.add(new Score(username, score));
            }
        }

        return leaderboard;
    }

    public List<Score> getAllScoresWithUserAndQuiz() throws SQLException {
        List<Score> scores = new ArrayList<>();
        String sql = "SELECT s.score, u.username, q.quiz_name FROM scores s " +
                     "JOIN users u ON s.user_id = u.user_id " +
                     "JOIN quizzes q ON s.quiz_id = q.quiz_id";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Score score = new Score();
                score.setScore(rs.getInt("score"));
                score.setUsername(rs.getString("username"));
                score.setQuizName(rs.getString("quiz_name"));
                scores.add(score);
            }
        }
        return scores;
    }

}
