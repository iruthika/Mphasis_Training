package com.testQuiz.dao;

import java.sql.*;
import com.testQuiz.entity.UserAnswer;
import com.testQuiz.entity.UserQuizAttempt;

public class UserAnswerDAO {
	private Connection connection;

	public UserAnswerDAO(Connection connection) {
		this.connection = connection;
	}

	public void saveUserAnswer(UserAnswer attempt) throws SQLException {
		String sql = "INSERT INTO user_quiz_attempts (user_id, quiz_id, score) VALUES (?, ?, ?)";
		try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			stmt.setInt(1, attempt.getUserId());
			stmt.setInt(2, attempt.getQuizId());
			stmt.setInt(3, attempt.getScore());
			stmt.executeUpdate();
		}
	}
}