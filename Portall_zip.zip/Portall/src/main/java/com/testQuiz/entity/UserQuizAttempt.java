package com.testQuiz.entity;

import java.sql.Timestamp;

public class UserQuizAttempt {

	 private int id;
	    private int userId;
	    private int quizId;
	    private int score;
	    private Timestamp attemptTime;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public int getQuizId() {
			return quizId;
		}
		public void setQuizId(int quizId) {
			this.quizId = quizId;
		}
		public int getScore() {
			return score;
		}
		public void setScore(int score) {
			this.score = score;
		}
		public Timestamp getAttemptTime() {
			return attemptTime;
		}
		public void setAttemptTime(Timestamp attemptTime) {
			this.attemptTime = attemptTime;
		}
		@Override
		public String toString() {
			return "UserQuizAttempt [id=" + id + ", userId=" + userId + ", quizId=" + quizId + ", score=" + score
					+ ", attemptTime=" + attemptTime + "]";
		}
		public UserQuizAttempt(int id, int userId, int quizId, int score, Timestamp attemptTime) {
			super();
			this.id = id;
			this.userId = userId;
			this.quizId = quizId;
			this.score = score;
			this.attemptTime = attemptTime;
		}
		public UserQuizAttempt() {
			super();
		}

}
